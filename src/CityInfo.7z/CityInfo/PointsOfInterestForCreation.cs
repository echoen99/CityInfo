﻿namespace CityInfo.API.Controllers
{
    public class PointsOfInterestForCreation
    {
    }
}